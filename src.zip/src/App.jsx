import './App.css'
import Image from './components/Image'

import courageScaredUrl from './assets/courage-scared.png';
import courageEyesUrl from './assets/courage-eyes.png';
import courageEustaceUrl from './assets/courage-eustace.jpg';
import courageMurielUrl from './assets/courage-muriel2.jpg';

function App(){
  const images = [
    {id: 1, imgFile: courageScaredUrl, width:"300", alt:"Courage looking terrified."},
    {id: 2, imgFile: courageEyesUrl, width:"300", alt:"Courage with eyes popping out in fear."},
    {id: 3, imgFile: courageEustaceUrl, width:"300", alt:"Eustace yelling."},
    {id: 4, imgFile: courageMurielUrl, width:"300", alt:"Muriel smiling."},
  ];//end images


  return(
    <main>
      <h1>Courage The Cowardly Dog</h1>
      <div className="cartoon-gallery-grid">
        {images.map((image) => 
          (<Image key={image.id} imgFile={image.imgFile} width={image.width} alt={image.alt} />
        ))}
      </div>
    </main>
  )
}

export default App
