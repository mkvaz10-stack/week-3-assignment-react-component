export default function Image({imgFile,width,alt}){
    return(
        <div className="image-card">
            <img src={imgFile}
            width={width}
            alt={alt} />
        </div>
    );
}//end Image({imgFile,width,alt})